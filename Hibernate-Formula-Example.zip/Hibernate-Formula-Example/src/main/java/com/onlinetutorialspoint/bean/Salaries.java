package com.onlinetutorialspoint.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Formula;

@Entity
@Table(name = "salaries")
public class Salaries {
	@Id
	@Column(name = "empid")
	private int empId;
	@Column(name = "empname")
	private String empName;
	@Column(name = "basic")
	private int basic;
	@Column(name = "conveyance")
	private int conveyance;
	@Column(name = "hra")
	private int hra;

	@Formula("(select min(s.hra) from salaries s) ")
	private float total;

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public int getBasic() {
		return basic;
	}

	public void setBasic(int basic) {
		this.basic = basic;
	}

	public int getConveyance() {
		return conveyance;
	}

	public void setConveyance(int conveyance) {
		this.conveyance = conveyance;
	}

	public int getHra() {
		return hra;
	}

	public void setHra(int hra) {
		this.hra = hra;
	}

	public float getTotal() {
		return total;
	}

	public void setTotal(float total) {
		this.total = total;
	}

}
